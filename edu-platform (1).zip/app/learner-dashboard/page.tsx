import { LearnerDashboard } from '@/components/learner-dashboard'

export default function LearnerDashboardPage() {
  return <LearnerDashboard />
}

