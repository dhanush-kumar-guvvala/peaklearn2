"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ThemeToggle } from '@/components/theme-toggle'

const courses = [
  { 
    id: 1, 
    title: 'React Fundamentals', 
    mentor: 'John Doe',
    videos: [
      { id: 1, title: 'Introduction to React', description: 'Learn the basics of React' },
      { id: 2, title: 'React Hooks', description: 'Understand and use React Hooks' },
    ]
  },
  { 
    id: 2, 
    title: 'Advanced JavaScript', 
    mentor: 'Jane Smith',
    videos: [
      { id: 3, title: 'Closures', description: 'Deep dive into JavaScript closures' },
      { id: 4, title: 'Promises', description: 'Master asynchronous JavaScript with Promises' },
    ]
  },
]

export default function PublicPage() {
  const [showSignIn, setShowSignIn] = useState(false)
  const router = useRouter()

  const neonBorderClasses = "border-2 border-transparent transition-all duration-300 ease-in-out hover:border-blue-500 hover:shadow-[0_0_10px_rgba(59,130,246,0.5)] dark:hover:border-purple-500 dark:hover:shadow-[0_0_10px_rgba(168,85,247,0.5)]"

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault()
    router.push('/login')
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">ProLearn</h1>
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <Button onClick={() => router.push('/login')} className="transition-all duration-200 hover:scale-105 active:scale-95">
            Sign In
          </Button>
        </div>
      </header>

      <main>
        <h2 className="text-2xl font-bold mb-4">Available Courses</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map(course => (
            <Card key={course.id} className={`${neonBorderClasses} transition-all duration-200 hover:scale-105`}>
              <CardHeader>
                <CardTitle>{course.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-2">Mentor: {course.mentor}</p>
                <h3 className="font-semibold mb-2">Videos:</h3>
                <ul className="list-disc list-inside">
                  {course.videos.map(video => (
                    <li key={video.id}>
                      <Dialog open={showSignIn} onOpenChange={setShowSignIn}>
                        <DialogTrigger asChild>
                          <Button variant="link" className="p-0 h-auto font-normal transition-all duration-200 hover:scale-105 active:scale-95">
                            {video.title}
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Sign In to Watch</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={handleSignIn} className="space-y-4">
                            <div>
                              <Label htmlFor="email">Email</Label>
                              <Input id="email" type="email" placeholder="Enter your email" />
                            </div>
                            <div>
                              <Label htmlFor="password">Password</Label>
                              <Input id="password" type="password" placeholder="Enter your password" />
                            </div>
                            <Button type="submit" className="w-full transition-all duration-200 hover:scale-105 active:scale-95">
                              Sign In
                            </Button>
                          </form>
                          <p className="text-center mt-4">
                            Don't have an account?{" "}
                            <Button variant="link" className="p-0 h-auto transition-all duration-200 hover:scale-105 active:scale-95">
                              Sign Up
                            </Button>
                          </p>
                        </DialogContent>
                      </Dialog>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}

