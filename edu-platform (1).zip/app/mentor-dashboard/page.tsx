import { MentorDashboard } from '@/components/mentor-dashboard'

export default function MentorDashboardPage() {
  return <MentorDashboard />
}

