"use client"

import { useState, useCallback } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ThemeToggle } from '@/components/theme-toggle'
import { VideoPlayer } from '@/components/video-player'
import { Chatbot } from '@/components/chatbot'
import { UserPerformance } from '@/components/user-performance'
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { X, Info } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { AnimatePresence, motion } from 'framer-motion'

export function LearnerDashboard() {
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [selectedVideo, setSelectedVideo] = useState(null)
  const [isWatching, setIsWatching] = useState(false)
  const [showChatbot, setShowChatbot] = useState(false)
  const [feedbackPosition, setFeedbackPosition] = useState('below')

  const toggleChatbot = useCallback(() => {
    setShowChatbot(prev => {
      const newShowChatbot = !prev
      setFeedbackPosition(newShowChatbot ? 'corner' : 'below')
      return newShowChatbot
    })
  }, [])

  const courses = [
    { 
      id: 1, 
      title: 'React Fundamentals', 
      mentor: 'John Doe',
      mentorInfo: 'Experienced React developer with 10 years in the industry.',
      videos: [
        { id: 1, title: 'Introduction to React', description: 'Learn the basics of React' },
        { id: 2, title: 'React Hooks', description: 'Understand and use React Hooks' },
      ]
    },
    { 
      id: 2, 
      title: 'Advanced JavaScript', 
      mentor: 'Jane Smith',
      mentorInfo: 'JavaScript expert and author of multiple programming books.',
      videos: [
        { id: 3, title: 'Closures', description: 'Deep dive into JavaScript closures' },
        { id: 4, title: 'Promises', description: 'Master asynchronous JavaScript with Promises' },
      ]
    },
  ]

  const neonBorderClasses = "border-2 border-transparent transition-all duration-300 ease-in-out hover:border-blue-500 hover:shadow-[0_0_10px_rgba(59,130,246,0.5)] dark:hover:border-purple-500 dark:hover:shadow-[0_0_10px_rgba(168,85,247,0.5)]"

  const renderContent = () => {
    if (isWatching && selectedVideo) {
      return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 relative">
          <div className="lg:col-span-2 space-y-4">
            <Card className={`overflow-hidden ${neonBorderClasses}`}>
              <CardContent className="p-0">
                <VideoPlayer video={selectedVideo} />
              </CardContent>
            </Card>
            <Button 
              onClick={toggleChatbot} 
              className={`w-full ${neonBorderClasses} transition-all duration-300 ${showChatbot ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'}`}
            >
              {showChatbot ? 'Close AI Assistant' : 'Open AI Assistant'}
            </Button>
            {showChatbot && <Chatbot onClose={toggleChatbot} />}
            <AnimatePresence>
              {feedbackPosition === 'below' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className={`${neonBorderClasses}`}>
                    <CardHeader>
                      <CardTitle>Feedback</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Textarea placeholder="Provide feedback on this video" className="mb-2" />
                      <Button className="transition-all duration-200 hover:scale-105 active:scale-95">Submit Feedback</Button>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <div className="space-y-4">
            <Card className={`${neonBorderClasses} transition-all duration-300 hover:scale-105`}>
              <CardHeader>
                <CardTitle>Notebook</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea placeholder="Take notes here" className="mb-2" />
                <Button className="transition-all duration-200 hover:scale-105 active:scale-95">Download Notes</Button>
              </CardContent>
            </Card>
            <Card className={`${neonBorderClasses} transition-all duration-300 hover:scale-105`}>
              <CardHeader>
                <CardTitle>Sketchbook</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="w-full h-40 bg-gray-200 rounded mb-2"></div>
                <Button className="transition-all duration-200 hover:scale-105 active:scale-95">Clear Sketch</Button>
              </CardContent>
            </Card>
          </div>
          <AnimatePresence>
            {feedbackPosition === 'corner' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3 }}
                className="fixed bottom-4 right-4 w-80"
              >
                <Card className={`${neonBorderClasses}`}>
                  <CardHeader>
                    <CardTitle>Feedback</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea placeholder="Provide feedback on this video" className="mb-2" />
                    <Button className="transition-all duration-200 hover:scale-105 active:scale-95">Submit Feedback</Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )
    } else if (selectedCourse) {
      return (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-3xl font-bold">{selectedCourse.title}</h2>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Info className="w-4 h-4 mr-2" />
                  Mentor Info
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{selectedCourse.mentor}</DialogTitle>
                </DialogHeader>
                <p>{selectedCourse.mentorInfo}</p>
              </DialogContent>
            </Dialog>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {selectedCourse.videos.map(video => (
              <Card key={video.id} className={`${neonBorderClasses} transition-all duration-300 hover:scale-105`}>
                <CardHeader>
                  <CardTitle>{video.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{video.description}</p>
                  <Button
                    className={`mt-2 w-full ${neonBorderClasses} transition-all duration-200 hover:scale-105 active:scale-95`}
                    onClick={() => {
                      setSelectedVideo(video)
                      setIsWatching(true)
                    }}
                  >
                    Watch
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )
    } else {
      return (
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold mb-4">Welcome to EduPlatform</h2>
          <p className="text-xl mb-4">Explore our courses and start learning today!</p>
          <p className="text-lg">Select a course from the sidebar to view its content.</p>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {courses.map(course => (
              <Card key={course.id} className={`${neonBorderClasses} transition-all duration-300 hover:scale-105`}>
                <CardHeader>
                  <CardTitle>{course.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Mentor: {course.mentor}</p>
                  <Button
                    className={`mt-4 w-full ${neonBorderClasses} transition-all duration-200 hover:scale-105 active:scale-95`}
                    onClick={() => {
                      setSelectedCourse(course)
                      setIsWatching(false)
                    }}
                  >
                    View Course
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Top bar */}
      <div className="flex justify-between items-center p-4 bg-background text-foreground border-b">
        <h1 className="text-2xl font-bold">EduPlatform</h1>
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <Button variant="default" onClick={() => setSelectedCourse(null)}>
            Course List
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-grow flex overflow-hidden">
        {/* Sidebar (hidden when course is selected) */}
        <div className={`w-64 p-4 bg-muted transition-all duration-300 ease-in-out ${selectedCourse ? '-ml-64' : 'ml-0'}`}>
          <h2 className="text-xl font-bold mb-4">Available Courses</h2>
          <ul className="space-y-2">
            {courses.map(course => (
              <li key={course.id}>
                <Button
                  variant="ghost"
                  className={`w-full justify-start ${neonBorderClasses}`}
                  onClick={() => {
                    setSelectedCourse(course)
                    setIsWatching(false)
                  }}
                >
                  {course.title}
                </Button>
              </li>
            ))}
          </ul>
        </div>

        {/* Main content area (full width) */}
        <div className="flex-grow p-4 overflow-auto">
          {renderContent()}
        </div>

        {/* User info sidebar (slides in when course is selected) */}
        <div className={`w-64 p-4 bg-muted transition-all duration-300 ease-in-out ${selectedCourse ? 'mr-0' : '-mr-64'}`}>
          <Card className={`mb-4 ${neonBorderClasses}`}>
            <CardHeader>
              <CardTitle>User Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <p>John Doe</p>
              <p>john@example.com</p>
            </CardContent>
          </Card>
          <div className={neonBorderClasses}>
            <UserPerformance />
          </div>
        </div>
      </div>
    </div>
  )
}

