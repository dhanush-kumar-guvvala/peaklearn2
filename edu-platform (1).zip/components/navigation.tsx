"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from "@/components/ui/button"

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="bg-background border-b p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/">
          <Button variant="link" className="text-2xl font-bold">EduPlatform</Button>
        </Link>
        <div className="space-x-4">
          <Link href="/learner-dashboard">
            <Button variant={pathname === '/learner-dashboard' ? 'default' : 'ghost'} className="transition-all duration-200 hover:scale-105 active:scale-95">
              Learner Dashboard
            </Button>
          </Link>
          <Link href="/mentor-dashboard">
            <Button variant={pathname === '/mentor-dashboard' ? 'default' : 'ghost'} className="transition-all duration-200 hover:scale-105 active:scale-95">
              Mentor Dashboard
            </Button>
          </Link>
          <Link href="/login">
            <Button variant="outline" className="transition-all duration-200 hover:scale-105 active:scale-95">
              Login
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  )
}

