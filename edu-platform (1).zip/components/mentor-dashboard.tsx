"use client"

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ThemeToggle } from '@/components/theme-toggle'

export function MentorDashboard() {
  const [videos, setVideos] = useState([
    { id: 1, title: 'Introduction to React', views: 1000, watchTime: '2h 30m', feedback: 4.5 },
    { id: 2, title: 'Advanced JavaScript Concepts', views: 800, watchTime: '3h 15m', feedback: 4.8 },
  ])

  const [newVideo, setNewVideo] = useState({
    title: '',
    description: '',
    courseName: '',
    videoNumber: '',
    timestamps: '',
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewVideo(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically handle video upload
    console.log('New video:', newVideo)
    // Reset form
    setNewVideo({
      title: '',
      description: '',
      courseName: '',
      videoNumber: '',
      timestamps: '',
    })
  }

  const neonBorderClasses = "border-2 border-transparent transition-all duration-300 ease-in-out hover:border-blue-500 hover:shadow-[0_0_10px_rgba(59,130,246,0.5)] dark:hover:border-purple-500 dark:hover:shadow-[0_0_10px_rgba(168,85,247,0.5)]"

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Mentor Dashboard</h1>
        <ThemeToggle />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className={neonBorderClasses}>
          <CardHeader>
            <CardTitle>Upload New Video</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Video Title</Label>
                <Input
                  id="title"
                  name="title"
                  value={newVideo.title}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Video Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={newVideo.description}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="courseName">Course Name</Label>
                <Input
                  id="courseName"
                  name="courseName"
                  value={newVideo.courseName}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="videoNumber">Video Number</Label>
                <Input
                  id="videoNumber"
                  name="videoNumber"
                  type="number"
                  value={newVideo.videoNumber}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="timestamps">Important Timestamps (comma-separated)</Label>
                <Input
                  id="timestamps"
                  name="timestamps"
                  value={newVideo.timestamps}
                  onChange={handleInputChange}
                  placeholder="e.g., 1:30,4:15,7:00"
                />
              </div>
              <Button type="submit" className="transition-all duration-200 hover:scale-105 active:scale-95">Upload Video</Button>
            </form>
          </CardContent>
        </Card>
        <Card className={neonBorderClasses}>
          <CardHeader>
            <CardTitle>Uploaded Videos</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {videos.map(video => (
                <li key={video.id} className="border-b pb-2">
                  <h3 className="font-semibold">{video.title}</h3>
                  <p>Views: {video.views}</p>
                  <p>Watch Time: {video.watchTime}</p>
                  <p>Feedback: {video.feedback}/5</p>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

