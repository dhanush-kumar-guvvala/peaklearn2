"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export function UserPerformance() {
  const [courses, setCourses] = useState([
    { id: 1, title: 'React Fundamentals', progress: 0 },
    { id: 2, title: 'Advanced JavaScript', progress: 0 },
  ])

  useEffect(() => {
    // Simulate progress updates
    const interval = setInterval(() => {
      setCourses(prevCourses => 
        prevCourses.map(course => ({
          ...course,
          progress: Math.min(course.progress + 10, 100)
        }))
      )
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Progress</CardTitle>
      </CardHeader>
      <CardContent>
        {courses.map(course => (
          <div key={course.id} className="mb-4">
            <h4 className="font-semibold">{course.title}</h4>
            <Progress value={course.progress} className="mt-2" />
            {course.progress === 50 && (
              <div className="text-green-500 mt-1 animate-bounce">
                50% Milestone Reached!
              </div>
            )}
            {course.progress === 100 && (
              <div className="text-green-500 mt-1 animate-pulse">
                Course Completed!
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

